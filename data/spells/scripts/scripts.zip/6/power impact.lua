local combat = createCombatObject()
setCombatParam(combat, COMBAT_PARAM_TYPE, COMBAT_ENERGYDAMAGE)
setCombatParam(combat, COMBAT_PARAM_EFFECT, 33)
setCombatParam(combat, COMBAT_PARAM_DISTANCEEFFECT, 48)
setCombatFormula(combat, COMBAT_FORMULA_LEVELMAGIC, -5.0, 0, -5.1, 0)


function onCastSpell(cid, var)
doPlayerSay(cid, 'Power Impact', TALKTYPE_ORANGE_1) 
return doCombat(cid, combat, var)
end



